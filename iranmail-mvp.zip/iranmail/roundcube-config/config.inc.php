<?php
/*
 * IranMail — Roundcube Extra Configuration
 * This file supplements the env-var config with advanced settings
 */

// ── Product branding ──
$config['product_name'] = 'IranMail';

// ── Security: allow self-signed TLS for local Stalwart ──
// !! Change to TRUE in production with real certs !!
$config['imap_conn_options'] = [
    'ssl' => [
        'verify_peer'       => false,
        'verify_peer_name'  => false,
        'allow_self_signed' => true,
    ]
];
$config['smtp_conn_options'] = [
    'ssl' => [
        'verify_peer'       => false,
        'verify_peer_name'  => false,
        'allow_self_signed' => true,
    ]
];

// ── Session & Security ──
$config['session_lifetime']  = 60;       // minutes
$config['login_autocomplete'] = 2;
$config['force_https']        = false;   // set true in production

// ── Features ──
$config['enable_spellcheck']    = true;
$config['delete_always']        = false;
$config['flag_for_deletion']    = false;
$config['read_when_deleted']    = true;
$config['signature_above_body'] = true;
$config['htmleditor']           = 3;      // always HTML compose

// ── Pagination ──
$config['pagesize'] = 50;

// ── Attachments ──
$config['max_message_size']  = '25M';

// ── Persian / RTL Support ──
$config['language'] = 'fa_IR';
$config['timezone'] = 'Asia/Tehran';

// ── Default folders ──
$config['drafts_mbox']  = 'Drafts';
$config['sent_mbox']    = 'Sent';
$config['junk_mbox']    = 'Junk';
$config['trash_mbox']   = 'Trash';

// ── Auto-create standard folders ──
$config['create_default_folders'] = true;

// ── Plugins ──
$config['plugins'] = [
    'archive',          // Archive folder support
    'zipdownload',      // Download multiple attachments as ZIP
    'managesieve',      // Server-side email filters (Sieve)
    'emoticons',        // Emoji support
    'newmail_notifier', // Desktop notification on new mail
];

// ── JMAP / ManageSieve (server-side filters via Stalwart) ──
$config['managesieve_host']     = 'stalwart';
$config['managesieve_port']     = 4190;
$config['managesieve_usetls']   = false;
$config['managesieve_conn_options'] = [
    'ssl' => [
        'verify_peer'       => false,
        'allow_self_signed' => true,
    ]
];
